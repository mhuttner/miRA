#include "testerino.h"

void test_valid_line(struct test *t);
void test_header_line(struct test *t);
void test_invalid_line(struct test *t);
void test_multiple_consecutive_tabs(struct test *t);