#include "testerino.h"

void test_strip_newlines(struct test *t);
void test_read_fasta_file(struct test *t);
