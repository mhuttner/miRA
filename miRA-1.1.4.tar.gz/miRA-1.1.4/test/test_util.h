#include "testerino.h"

#ifndef TEST_UTIL_H
#define TEST_UTIL_H

void test_mean(struct test *t);
void test_sd(struct test *t);
void test_pvalue(struct test *t);
void test_config_parsing(struct test *t);

#endif