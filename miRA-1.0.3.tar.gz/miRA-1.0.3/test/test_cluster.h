#include "testerino.h"

void test_create_clusters(struct test *t);

void test_sort_clusters(struct test *t);
void test_merge_clusters(struct test *t);
void test_filter_clusters(struct test *t);
void test_merge_extended_clusters(struct test *t);