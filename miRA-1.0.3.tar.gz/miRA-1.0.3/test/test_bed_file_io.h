#include "testerino.h"

#ifndef TEST_BED_FILE_IO_H
#define TEST_BED_FILE_IO_H

void test_valid_bed_line(struct test *t);
void test_invalid_start_bed_line(struct test *t);
void test_invalid_id_bed_line(struct test *t);

#endif
