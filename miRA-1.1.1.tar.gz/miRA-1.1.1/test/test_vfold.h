#include "testerino.h"

#ifndef TEST_VFOLD_H
#define TEST_VFOLD_H

void test_reverse_complement(struct test *t);
void test_folding(struct test *t);

#endif
